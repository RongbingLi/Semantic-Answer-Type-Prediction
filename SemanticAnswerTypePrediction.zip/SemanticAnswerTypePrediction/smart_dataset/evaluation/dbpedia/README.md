Evaluation Script
